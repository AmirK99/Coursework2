package Step_2;

public class TeamMember {
	String name;
	int employeeNumber;
	String division;
}
