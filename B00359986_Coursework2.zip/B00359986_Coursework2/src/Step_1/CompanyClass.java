package Step_1;

public class CompanyClass {
	String project_Title;
	int start_end_date;
}
