package Step_1;

public class Main {
	
	public static void main(String[] args) {
		CompanyTest menu = new CompanyTest();
		menu.runProjectMenu();
		
	}
	
}
